<?php
/* Smarty version 3.1.31, created on 2018-07-14 21:10:28
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\empty.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b4a3c94f2ac60_24230745',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10153c9f7e0691966fa3f761c445610f992c6370' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\empty.tpl',
      1 => 1531562521,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b4a3c94f2ac60_24230745 (Smarty_Internal_Template $_smarty_tpl) {
?>
 <?php }
}
