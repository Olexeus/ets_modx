<?php
/* Smarty version 3.1.31, created on 2018-07-14 13:29:56
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\element\snippet\update.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b49d0a4554400_70652014',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0ddd889ae73cdf53626242be84ffb37deeed90b1' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\element\\snippet\\update.tpl',
      1 => 1531562520,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b49d0a4554400_70652014 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="modx-panel-snippet-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onSnipFormPrerender']->value;
}
}
