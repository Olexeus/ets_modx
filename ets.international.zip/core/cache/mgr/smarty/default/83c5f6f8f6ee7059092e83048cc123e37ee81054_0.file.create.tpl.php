<?php
/* Smarty version 3.1.31, created on 2018-07-23 19:19:24
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\element\template\create.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b56000ccba653_57554565',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '83c5f6f8f6ee7059092e83048cc123e37ee81054' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\element\\template\\create.tpl',
      1 => 1531562520,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b56000ccba653_57554565 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTempFormPrerender']->value;
}
}
