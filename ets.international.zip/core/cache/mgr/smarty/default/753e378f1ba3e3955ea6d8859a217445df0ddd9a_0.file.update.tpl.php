<?php
/* Smarty version 3.1.31, created on 2018-07-16 12:10:18
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\element\plugin\update.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b4c60fae88de7_76799796',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '753e378f1ba3e3955ea6d8859a217445df0ddd9a' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\element\\plugin\\update.tpl',
      1 => 1531562520,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b4c60fae88de7_76799796 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="modx-panel-plugin-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onPluginFormPrerender']->value;
}
}
