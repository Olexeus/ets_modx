<?php  return array (
  1 => 
  array (
    'id' => '1',
    'namespace' => 'collections',
    'controller' => 'index',
    'haslayout' => '1',
    'lang_topics' => 'collections:default',
    'assets' => '',
    'help_url' => '',
    'namespace_name' => 'collections',
    'namespace_path' => 'D:/Programs/open_server/OSPanel/domains/ets.international/core/components/collections/',
    'namespace_assets_path' => '{assets_path}components/collections/',
  ),
  2 => 
  array (
    'id' => '2',
    'namespace' => 'formit',
    'controller' => 'index',
    'haslayout' => '1',
    'lang_topics' => 'formit:mgr',
    'assets' => '',
    'help_url' => '',
    'namespace_name' => 'formit',
    'namespace_path' => 'D:/Programs/open_server/OSPanel/domains/ets.international/core/components/formit/',
    'namespace_assets_path' => '{assets_path}components/formit/',
  ),
  3 => 
  array (
    'id' => '3',
    'namespace' => 'migx',
    'controller' => 'index',
    'haslayout' => '0',
    'lang_topics' => 'example:default',
    'assets' => '',
    'help_url' => '',
    'namespace_name' => 'migx',
    'namespace_path' => 'D:/Programs/open_server/OSPanel/domains/ets.international/core/components/migx/',
    'namespace_assets_path' => '{assets_path}components/migx/',
  ),
);