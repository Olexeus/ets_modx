<?php
/* Smarty version 3.1.31, created on 2018-07-14 13:03:06
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\welcome.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b49ca5ae34238_84118054',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '069cd30dadd5144554a9631eea6672ae75d689e1' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\welcome.tpl',
      1 => 1531562521,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b49ca5ae34238_84118054 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="modx-panel-welcome-div"></div>

<div id="modx-dashboard" class="dashboard">
<?php echo $_smarty_tpl->tpl_vars['dashboard']->value;?>

</div><?php }
}
