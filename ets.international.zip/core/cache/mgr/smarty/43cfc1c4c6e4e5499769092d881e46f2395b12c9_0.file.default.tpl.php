<?php
/* Smarty version 3.1.31, created on 2018-07-14 21:10:29
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\element\tv\renders\properties\default.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b4a3c9521a781_83663649',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '43cfc1c4c6e4e5499769092d881e46f2395b12c9' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\element\\tv\\renders\\properties\\default.tpl',
      1 => 1531562521,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b4a3c9521a781_83663649 (Smarty_Internal_Template $_smarty_tpl) {
?>
&nbsp;<?php }
}
