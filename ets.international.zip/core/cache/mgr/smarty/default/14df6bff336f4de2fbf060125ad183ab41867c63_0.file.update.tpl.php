<?php
/* Smarty version 3.1.31, created on 2018-07-14 13:47:10
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\element\template\update.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b49d4ae18f9b8_01330423',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '14df6bff336f4de2fbf060125ad183ab41867c63' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\element\\template\\update.tpl',
      1 => 1531562520,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b49d4ae18f9b8_01330423 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTempFormPrerender']->value;
}
}
