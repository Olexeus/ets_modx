<?php
/* Smarty version 3.1.31, created on 2018-07-24 00:18:06
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\security\user\create.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b56460e3c0696_17242849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8c9c6c10b810b14e703153bbb3fd4f18895124cb' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\security\\user\\create.tpl',
      1 => 1531562520,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b56460e3c0696_17242849 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['OnUserFormPrerender']->value;?>

<div id="modx-panel-user-div"></div><?php }
}
