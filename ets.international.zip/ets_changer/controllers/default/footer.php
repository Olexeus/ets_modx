<?php
/**
 * Loads the footer
 *
 * @package modx
 * @subpackage manager.controllers
 */