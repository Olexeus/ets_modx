<?php
require_once (dirname(dirname(__FILE__)) . '/migxconfig.class.php');
class migxConfig_mysql extends migxConfig {}