<?php
/* Smarty version 3.1.31, created on 2018-07-14 13:04:17
  from "D:\Programs\open_server\OSPanel\domains\ets.international\ets_changer\templates\default\workspaces\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b49caa174a1a4_91711161',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '70ee5a0f9c3177a0e95e88590ff1a5c42f09550f' => 
    array (
      0 => 'D:\\Programs\\open_server\\OSPanel\\domains\\ets.international\\ets_changer\\templates\\default\\workspaces\\index.tpl',
      1 => 1531562521,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b49caa174a1a4_91711161 (Smarty_Internal_Template $_smarty_tpl) {
echo (($tmp = @$_smarty_tpl->tpl_vars['error']->value)===null||$tmp==='' ? '' : $tmp);?>

<div id="modx-panel-workspace-div"></div>
<?php }
}
